import random


class Szin:
    feher = (255,255,255)
    fekete = (0,0,0)
    kek = (0,0,255)
    piros = (255,0,0)

class Ablak:
    szelesseg = 800
    magassag = 800
    hatterszin = Szin.fekete


class Babu:
    ures = 0
    iksz = 1
    kor = 2


class Jatek:

    def __init__(self, jatekos_nev, ai_nev, meret=None, nehezseg=None):

        """ Pálya méret definiálása """
        if meret is None:
            self.meret = 5
        else:
            self.meret = meret

        """ Játék nehézség definiálása """
        if nehezseg is None:
            self.nehezseg = 1
        else:
            self.nehezseg = nehezseg

        """ Pálya létrehozása """
        self.palya = []
        for _ in range(self.meret):
            self.palya.append([Babu.ures] * self.meret)

        self.kornev = jatekos_nev
        self.xnev = ai_nev
        self.kezdes = random.choice([self.kornev, self.xnev])
        if self.kezdes == self.kornev:
            self.kovetkezo = jatekos_nev
        else:
            self.kovetkezo = ai_nev


class Pozicio:

    def __init__(self, x, y):
        self.x = x
        self.y = y


class AIMemoria:

    utolso_kor = None
    utolso_tamadas = None
    vedes_kezdet = 3
