import random
import classok
import grafika


def kovetkezo(j):
    if j.kovetkezo == j.kornev:
        j.kovetkezo = j.xnev
    elif j.kovetkezo == j.xnev:
        j.kovetkezo = j.kornev


def lerak(j, p):
    if j.kovetkezo == j.kornev:
        j.palya[p.x][p.y] = classok.Babu.kor
    elif j.kovetkezo == j.xnev:
        j.palya[p.x][p.y] = classok.Babu.iksz


def foglalt(j, p):
    if j.palya[p.x][p.y] == classok.Babu.ures:
        return False
    else:
        return True


def betelt(j):
    for x in range(j.meret):
        for y in range(j.meret):
            if j.palya[x][y] == classok.Babu.ures:
                return False
    return True


def jatekos_babuja(j):
    if j.kovetkezo == j.kornev:
        return classok.Babu.kor
    elif j.kovetkezo == j.xnev:
        return classok.Babu.iksz


def fuggoleges(j, p, kell):
    db = 0
    # pozíciótól + irányba nézve hány db bábu van
    for n in range(kell):
        if p.x + n < len(j.palya):
            if j.palya[p.x + n][p.y] == jatekos_babuja(j):
                db += 1
            else:
                break

    # pozíciótól - irányba nézve hány db bábu van
    for n in range(1, kell):
        if 0 <= p.x - n:
            if j.palya[p.x - n][p.y] == jatekos_babuja(j):
                db += 1
            else:
                break
    return db


def vizszintes(j, p, kell):
    db = 0
    # pozíciótól + irányba nézve hány db bábu van
    for n in range(kell):
        if p.y + n < len(j.palya):
            if j.palya[p.x][p.y + n] == jatekos_babuja(j):
                db += 1
            else:
                break

    # pozíciótól - irányba nézve hány db bábu van
    for n in range(1, kell):
        if 0 <= p.y - n:
            if j.palya[p.x][p.y - n] == jatekos_babuja(j):
                db += 1
            else:
                break
    return db


def atlos(j, p, kell):
    # Bal fentről jobbra le és jobb lentről balra fel.
    db = 0
    for n in range(kell):
        if p.x + n < len(j.palya) and p.y + n < len(j.palya):
            if j.palya[p.x + n][p.y + n] == jatekos_babuja(j):
                db += 1
            else:
                break
    for n in range(1, kell):
        if 0 <= p.x - n and 0 <= p.y - n:
            if j.palya[p.x - n][p.y - n] == jatekos_babuja(j):
                db += 1
            else:
                break
    return db


def atlos2(j, p, kell):
    # Jobb fentről balra le és bal lentről jobbra fel
    db = 0
    for n in range(kell):
        if p.x + n < len(j.palya) and 0 <= p.y - n:
            if j.palya[p.x + n][p.y - n] == jatekos_babuja(j):
                db += 1
            else:
                break
    for n in range(1, kell):
        if 0 <= p.x - n and p.y + n < len(j.palya):
            if j.palya[p.x - n][p.y + n] == jatekos_babuja(j):
                db += 1
            else:
                break
    return db


def nyert(j, p):
    # >= 5, mert 5 kell a győzelemhez
    if vizszintes(j, p, 5) >= 5:
        return True
    elif fuggoleges(j, p, 5) >= 5:
        return True
    elif atlos(j, p, 5) >= 5:
        return True
    elif atlos2(j, p, 5) >= 5:
        return True

    return False


def mentes(j):
    f = open("mentett_allas.txt", "w", encoding="utf-8")
    f.write(str(j.nehezseg))
    f.write("\n")
    f.write(str(j.kovetkezo))
    f.write("\n")
    for x in range(len(j.palya)):
        for y in range(len(j.palya)):
            f.write(str(j.palya[x][y]))
            if y != len(j.palya) - 1:
                f.write(",")
        f.write("\n")
    f.close()


def betoltes(j):
    try:
        f = open("mentett_allas.txt", "rt", encoding="utf-8")
        j.nehezseg = int(f.readline())
        j.kezdes = f.readline()
        j.palya = []
        x = 0
        for sor in f:
            sor = sor.rstrip('\n')
            darabolt = sor.split(',')
            j.palya.append([0] * len(darabolt))
            for y in range(len(darabolt)):
                j.palya[x][y] = int(darabolt[y])
            x += 1
    except():
        pass


def ai_konnyu(j):
    # Random lerakás
    while True:
        x = random.randint(0, j.meret - 1)
        y = random.randint(0, j.meret - 1)
        p = classok.Pozicio(x, y)
        if foglalt(j, p) is False:
            lerak(j, p)
            if nyert(j, p) is True:
                grafika.eredmenyrajz(j)
            if betelt(j) is True:
                j.kovetkezo = "Döntetlen"
                grafika.eredmenyrajz(j)
            return


def ai_nehez(j, ai):
    # Ha AI kezd
    if ai.utolso_tamadas is None:
        tamadaspoz(j,ai)
        return
    # AI lépés
    if nyer_e(j,ai) is False:
        if ai_vedekezes(j, ai) is False:
            tamadaspoz(j, ai)

    # Ellenőrzés
    if nyert(j, ai.utolso_tamadas) is True:
        grafika.eredmenyrajz(j)
    if betelt(j) is True:
        j.kovetkezo = "Döntetlen"
        grafika.eredmenyrajz(j)
    return


def nyer_e(j,ai):

    for k in range(j.meret):
        for l in range(j.meret):
            p = classok.Pozicio(k, l)
            if foglalt(j, p) is False:
                j.palya[p.x][p.y] = jatekos_babuja(j)
                if nyert(j, p) is True:
                    ai.utolso_tamadas = p
                    return True
                else:
                    j.palya[p.x][p.y] = classok.Babu.ures

    return False

def ai_vedekezes(j,ai):
    kovi = j.kovetkezo
    j.kovetkezo = j.kornev
    # Megkeresni hogy van-e olyan pozíció amiről Jatekos tud nyerni, és ha van, akkor oda X
    for k in range(j.meret):
        for l in range(j.meret):
            p = classok.Pozicio(k, l)
            if foglalt(j, p) is False:
                j.palya[p.x][p.y] = jatekos_babuja(j)
                if nyert(j, p) is True:
                    j.kovetkezo = kovi
                    lerak(j,p)
                    ai.utolso_tamadas = p
                    return True
                else:
                    j.palya[p.x][p.y] = classok.Babu.ures
    p = ai.utolso_kor
    # Megvizsgálni hogy melyik irányba van több mint 2 és elkezdeni védekezni
    if vizszintes(j, p, 5) >= classok.AIMemoria.vedes_kezdet:
        n = 1
        while True:
            if p.y + n >= len(j.palya):
                break
            else:
                if j.palya[p.x][p.y + n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x][p.y + n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x][p.y + n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x, p.y + n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

        n = 1
        while True:
            if p.y - n < 0:
                break
            else:
                if j.palya[p.x][p.y - n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x][p.y - n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x][p.y - n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x, p.y - n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

    if fuggoleges(j, p, 5)>= classok.AIMemoria.vedes_kezdet:
        n = 1
        while True:
            if p.x + n >= len(j.palya):
                break
            else:
                if j.palya[p.x + n][p.y] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x + n][p.y] == classok.Babu.iksz:
                    break
                elif j.palya[p.x + n][p.y] == classok.Babu.ures:
                    p = classok.Pozicio(p.x + n, p.y)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

        n = 1
        while True:
            if p.x - n < 0:
                break
            else:
                if j.palya[p.x - n][p.y] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x - n][p.y] == classok.Babu.iksz:
                    break
                elif j.palya[p.x - n][p.y] == classok.Babu.ures:
                    p = classok.Pozicio(p.x - n, p.y)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

    if atlos(j, p, 5)>= classok.AIMemoria.vedes_kezdet:
        n = 1
        while True:
            if p.x + n >= len(j.palya) or p.y + n >= len(j.palya):
                break
            else:
                if j.palya[p.x + n][p.y + n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x + n][p.y + n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x + n][p.y + n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x + n, p.y + n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

        n = 1
        while True:

            if 0 > p.x - n or 0 > p.y - n:
                break
            else:
                if j.palya[p.x - n][p.y - n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x - n][p.y - n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x - n][p.y - n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x - n, p.y - n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

    if atlos2(j, p, 5)>= classok.AIMemoria.vedes_kezdet:
        n = 1
        while True:
            if p.x + n >= len(j.palya) or 0 > p.y - n:
                break
            else:
                if j.palya[p.x + n][p.y - n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x + n][p.y - n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x + n][p.y - n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x + n, p.y - n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

        n = 1
        while True:
            if 0 > p.x - n or p.y + n >= len(j.palya):
                break
            else:
                if j.palya[p.x - n][p.y + n] == classok.Babu.kor:
                    n += 1
                elif j.palya[p.x - n][p.y + n] == classok.Babu.iksz:
                    break
                elif j.palya[p.x - n][p.y + n] == classok.Babu.ures:
                    p = classok.Pozicio(p.x - n, p.y + n)
                    j.kovetkezo = kovi
                    lerak(j, p)
                    return True

    j.kovetkezo = kovi
    return False


def tamadaspoz(j, ai):
    legjobbpoz = classok.Pozicio(0, 0)
    db = 0
    # Legjobb pozíció megkeresése
    for k in range(j.meret):
        for l in range(j.meret):
            p = classok.Pozicio(k, l)
            if foglalt(j, p) is False:
                j.palya[p.x][p.y] = classok.Babu.iksz
                # Ha azzal a pozícióval nyerne, akkor odalépni és return
                if nyert(j, p):
                    ai.utolso_tamadas = p
                    return
                pont = vizszintes(j, p, 5) + fuggoleges(j, p, 5) + atlos(j, p, 5) + atlos2(j, p, 5)
                j.palya[p.x][p.y] = classok.Babu.ures
                if pont > db:
                    db = pont
                    legjobbpoz = p
    lerak(j, legjobbpoz)
    ai.utolso_tamadas = legjobbpoz
    return


