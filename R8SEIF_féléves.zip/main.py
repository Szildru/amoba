import classok
import grafika


def main():
    jatek = classok.Jatek("Játékos", "AI")
    grafika.fomenu(jatek)
main()
