import classok
import pygame
import sys
import jatekmenet


def Ablak():
    pygame.init()
    a = classok.Ablak
    ablak = pygame.display.set_mode((a.szelesseg, a.magassag))
    pygame.display.set_caption("Amőba")
    ablak.fill(a.hatterszin)
    return ablak

# region Rajzolás


def fomenu(j):
    ablak_menu = Ablak()

    betustilus_fejlec = pygame.font.SysFont('Arial', 50)
    betustilus_menupontok = pygame.font.SysFont('Arial', 35)

    # Fejléc megrajzolása
    fejlec = betustilus_fejlec.render('Amőba', True, classok.Szin.feher)
    ablak_menu.blit(fejlec, (330, 10))

    # új játék felirat megrajzolása
    uj_jatek = betustilus_menupontok.render('Új játék', True, classok.Szin.feher)
    ablak_menu.blit(uj_jatek, (30, 110))

    # "Mentett állás betöltése" felirat megrajzolása
    mentett_allas = betustilus_menupontok.render('Mentett állás betöltése', True, classok.Szin.feher)
    ablak_menu.blit(mentett_allas, (30, 210))

    # "Kilépés" felirat megrajzolása
    kilepes = betustilus_menupontok.render('Kilépés', True, classok.Szin.feher)
    ablak_menu.blit(kilepes, (30, 310))

    fomenu_vezerles(j)


def uj_jatek_beallitasok_rajz(j):
    ablak_uj_jatek = Ablak()

    betustilus_fejlec = pygame.font.SysFont('Arial', 50)
    betustilus_menupontok = pygame.font.SysFont('Arial', 35)
    betustilus_start = pygame.font.SysFont('Arial', 60)

    # Fejléc megrajzolása
    fejlec = betustilus_fejlec.render('Új játék', True, classok.Szin.feher)
    ablak_uj_jatek.blit(fejlec, (300, 10))

    # "Vissza a menübe" felirat megrajzolása
    vissza_a_menube = betustilus_menupontok.render('Vissza a menübe', True, classok.Szin.feher)
    ablak_uj_jatek.blit(vissza_a_menube, (550, 750))

    # "START" gomb megrajzolása
    start = betustilus_start.render('START', True, classok.Szin.feher)
    ablak_uj_jatek.blit(start, (300, 400))

    palyameret_rajz(ablak_uj_jatek, j)

    nehezseg_rajz(ablak_uj_jatek, j)

    uj_jatek_beallitasok_vezerles(j)


def palyameret_rajz(a, j):
    ablak_palyameret = a
    betustilus = pygame.font.SysFont('Arial', 40)
    betustilus2 = pygame.font.SysFont('Arial', 50)

    palyameret = betustilus.render("Pályaméret: ", True, classok.Szin.feher)
    minusz = betustilus2.render('-', True, classok.Szin.feher)
    plusz = betustilus2.render('+', True, classok.Szin.feher)
    ablak_palyameret.blit(palyameret, (50, 150))
    ablak_palyameret.blit(minusz, (50, 190))
    ablak_palyameret.blit(plusz, (225, 190))
    valasztas = betustilus.render(f'{j.meret:<2}x{j.meret:<2}', True, classok.Szin.feher)
    ablak_palyameret.blit(valasztas, (100, 200))


def nehezseg_rajz(a, j):
    betustilus = pygame.font.SysFont('Arial', 40)
    betustilus2 = pygame.font.SysFont('Arial', 50)
    nehezseg = betustilus.render("Nehézség: ", True, classok.Szin.feher)
    minusz = betustilus2.render('-', True, classok.Szin.feher)
    plusz = betustilus2.render('+', True, classok.Szin.feher)
    if j.nehezseg == 1:
        valasztas = betustilus.render('Könnyű', True, classok.Szin.feher)
    else:
        valasztas = betustilus.render('Nehéz', True, classok.Szin.feher)
    a.blit(minusz, (500, 190))
    a.blit(nehezseg, (500, 150))
    a.blit(valasztas, (550, 200))
    a.blit(plusz, (690, 190))


def mentett_allas_rajz(j):
    ablak_mentett = Ablak()
    betustilus_fejlec = pygame.font.SysFont('Arial', 50)
    betustilus_allasok = pygame.font.SysFont('Arial', 35)

    allas1 = betustilus_allasok.render("Mentett állás 1", True, classok.Szin.feher)
    ablak_mentett.blit(allas1, (30, 250))

    fejlec = betustilus_fejlec.render('Mentett állás betöltése', True, classok.Szin.feher)
    ablak_mentett.blit(fejlec, (210, 10))

    # "Vissza a menübe" felirat megrajzolása
    vissza_a_menube = betustilus_allasok.render('Vissza a menübe', True, classok.Szin.feher)
    ablak_mentett.blit(vissza_a_menube, (550, 750))

    vezerles_mentett_allas(j)


def palyarajz(j):

    fablak = Ablak()
    betustilus = pygame.font.SysFont('Times New Roman', 50)
    betustilus2 = pygame.font.SysFont('Times New Roman', 25)
    fejlec = betustilus.render('Amőba', True, classok.Szin.feher)
    mentes = betustilus2.render('Mentés', True, classok.Szin.feher)
    menu = betustilus2.render('Vissza a menübe', True, classok.Szin.feher)
    if j.kezdes == j.kornev:
        kezdesiras = betustilus.render("Te kezdesz!", True, classok.Szin.feher)
    else:
        kezdesiras = betustilus.render("A gép kezd.", True, classok.Szin.feher)
    # Ki kezd kiírása
    fablak.blit(kezdesiras, (300, 725))
    # Amőba felirat megrajzolás
    fablak.blit(fejlec, (325, 0))
    # Mentés felirat megrajzolás
    fablak.blit(mentes, (10, 10))
    # Vissza a menübe felirat megrajzolás
    fablak.blit(menu, (625, 10))
    hanyszor = 600 / j.meret

    # Négyzetrács megrajzolása
    for x in range(j.meret + 1):
        pygame.draw.line(fablak, classok.Szin.feher, (100 + (x * hanyszor), 100), (100 + (x * hanyszor), 700))
        pygame.draw.line(fablak, classok.Szin.feher, (100, 100 + (x * hanyszor)), (700, 100 + (x * hanyszor)))

    vezerles_jatekrajz(fablak, j)


def korrajz(a, j, p):
    egyseg = 600 / j.meret
    x = 100 + p.x * egyseg + egyseg/2
    y = 100 + p.y * egyseg + egyseg/2
    pygame.draw.circle(a, classok.Szin.kek, (y, x), egyseg/3)


def xrajz(a, p, j):
    egyseg = 600 / j.meret
    x1 = 100 + p.x * egyseg + egyseg / 3
    y1 = 100 + p.y * egyseg + egyseg / 3
    x2 = 100 + p.x * egyseg + (egyseg / 3) * 2
    y2 = 100 + p.y * egyseg + (egyseg / 3) * 2
    # két átlós vonal = x
    pygame.draw.line(a, classok.Szin.piros, (y1, x1), (y2, x2), int(egyseg//10))
    pygame.draw.line(a, classok.Szin.piros, (y2, x1), (y1, x2), int(egyseg//10))


def eredmenyrajz(j):
    fablak = Ablak()
    betustilus = pygame.font.SysFont('Times New Roman', 50)
    betustilusnagy = pygame.font.SysFont('Times New Roman', 100)
    betustilus_menupontok = pygame.font.SysFont('Arial', 35)
    fejlec = betustilus.render("A meccs eredménye:", True, classok.Szin.feher)

    if j.kovetkezo == "Döntetlen":
        gyoztes = betustilusnagy.render(f"Döntetlen", True, classok.Szin.feher)
        fablak.blit(gyoztes, (200, 300))
    elif j.kovetkezo == j.kornev:
        gyoztes = betustilusnagy.render(f"Te győztél!", True, classok.Szin.feher)
        fablak.blit(gyoztes, (200, 300))
    elif j.kovetkezo == j.xnev:
        gyoztes = betustilusnagy.render(f"A gép győzött", True, classok.Szin.feher)
        fablak.blit(gyoztes, (150, 300))

    fablak.blit(fejlec, (225, 0))

    vissza_a_menube = betustilus_menupontok.render('Vissza a menübe', True, classok.Szin.feher)
    fablak.blit(vissza_a_menube, (300, 750))

    uj_jatek = betustilus_menupontok.render('Új játék', True, classok.Szin.feher)
    fablak.blit(uj_jatek, (10, 750))

    kilepes = betustilus_menupontok.render('Kilépés', True, classok.Szin.feher)
    fablak.blit(kilepes, (690, 750))
    vezerles_eredmeny(j)


def betoltesrajz(a, j):

    for x in range(j.meret):
        for y in range(j.meret):
            if j.palya[x][y] == classok.Babu.kor:
                p = classok.Pozicio(x, y)
                korrajz(a, j, p)
            elif j.palya[x][y] == classok.Babu.iksz:
                p = classok.Pozicio(x, y)
                xrajz(a, p, j)

# endregion

# region Vezérlés


def vezerles_eredmeny(j):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                p = classok.Pozicio(event.pos[0], event.pos[1])
                if 690 <= p.x <= 800 and 750 <= p.y <= 800:  # "Kilépés" gomb kattintás
                    pygame.quit()
                    sys.exit()
                if 0 <= p.x <= 105 and 750 <= p.y <= 800:  # "Új játék" gomb kattinás
                    uj_jatek_beallitasok_rajz(j)
                if 300 <= p.x <= 550 and 750 <= p.y <= 800:  # "Vissza a menübe" gomb kattintás
                    fomenu(j)
        pygame.display.update()


def vezerles_jatekrajz(a, j):
    betoltesrajz(a, j)
    ai = classok.AIMemoria
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                p = classok.Pozicio(event.pos[0], event.pos[1])
                oszlop = int((p.y - 100) // (600 / j.meret))
                sor = int((p.x - 100) // (600 / j.meret))
                if 620 <= p.x <= 800 and 0 <= p.y <= 35:  # "vissza a menübe" gomb
                    fomenu(j)
                if 0 <= p.x <= 100 and 0 <= p.y <= 50:  # "Mentés" gombra kattintás
                    jatekmenet.mentes(j)
                if 0 <= sor < j.meret and 0 <= oszlop < j.meret:
                    p.x = oszlop
                    p.y = sor
                    if jatekmenet.foglalt(j, p) is False:
                        if j.kovetkezo == j.kornev:
                            jatekmenet.lerak(j, p)
                            ai.utolso_kor = p
                            betoltesrajz(a, j)
                            if jatekmenet.nyert(j, p) is True:
                                eredmenyrajz(j)
                            if jatekmenet.betelt(j) is True:
                                j.kovetkezo = "Döntetlen"
                                eredmenyrajz(j)
                            jatekmenet.kovetkezo(j)

            if event.type == pygame.MOUSEBUTTONUP:
                if j.nehezseg == 1:
                    if j.kovetkezo == j.xnev:
                        jatekmenet.ai_konnyu(j)
                        jatekmenet.kovetkezo(j)

                elif j.nehezseg == 2:
                    if j.kovetkezo == j.xnev:
                        jatekmenet.ai_nehez(j, ai)
                        jatekmenet.kovetkezo(j)

                betoltesrajz(a, j)

        pygame.display.update()


def uj_jatek_beallitasok_vezerles(j):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                p = classok.Pozicio(event.pos[0], event.pos[1])
                if 550 <= p.x <= 800 and 750 <= p.y <= 800:  # Vissza a menübe gomb
                    fomenu(j)
                if 290 <= p.x <= 465 and 400 <= p.y <= 460:  # START gomb

                    j2 = classok.Jatek("Játékos", "AI", j.meret, j.nehezseg)
                    palyarajz(j2)

                if 40 <= p.x <= 70 and 205 <= p.y <= 240:  # Méret "-" gomb
                    if j.meret > 5:  # minimum 5x5-ös pálya
                        j.meret -= 1
                        uj_jatek_beallitasok_rajz(j)
                if 220 <= p.x <= 250 and 205 <= p.y <= 240:  # Méret "+" gomb
                    if j.meret < 20:  # maximum 20#20-as pálya
                        j.meret += 1
                        uj_jatek_beallitasok_rajz(j)
                if 495 <= p.x <= 520 and 205 <= p.y <= 240:  # Nehézség "-" gomb
                    j.nehezseg = 1
                    uj_jatek_beallitasok_rajz(j)
                if 690 <= p.x <= 715 and 205 <= p.y <= 240:  # Nehézség "-+" gomb
                    j.nehezseg = 2
                    uj_jatek_beallitasok_rajz(j)
        pygame.display.update()


def vezerles_mentett_allas(j):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                p = classok.Pozicio(event.pos[0],event.pos[1])
                if 550 <= p.x <= 800 and 750 <= p.y <= 800: # Vissza a menübe feliratra kattintás
                    fomenu(j)
                if 0 <= p.x <= 150 and 250 <= p.y <= 300: # Mentett állásra kettintás
                    jatekmenet.betoltes(j)
                    palyarajz(j)
        pygame.display.update()


def fomenu_vezerles(j):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                p = classok.Pozicio(event.pos[0], event.pos[1])

                # "Új játék" gombra kattintás
                if 25 <= p.x <= 130 and 100 <= p.y <= 150:
                    uj_jatek_beallitasok_rajz(j)

                # "Mentett állás..." gomb kattintás
                elif 25 <= p.x <= 315 and 215 <= p.y <= 245:
                    mentett_allas_rajz(j)

                # "Kiléps" gombra kattintás
                elif 25 <= p.x <= 130 and 310 <= p.y <= 345:
                    pygame.quit()
                    sys.exit()
        pygame.display.update()


# endregion
